#!/bin/bash

# AWS ECR build and push script
# Replace these variables with your AWS account ID and region
AWS_ACCOUNT_ID="<YOUR_AWS_ACCOUNT_ID>"
AWS_REGION="<YOUR_AWS_REGION>"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

# Login to ECR
aws ecr get-login-password --region ${AWS_REGION} | docker login --username AWS --password-stdin ${ECR_REGISTRY}

# Create ECR repositories if they don't exist
aws ecr create-repository --repository-name shopping-ms-products --region ${AWS_REGION} 2>/dev/null || true
aws ecr create-repository --repository-name shopping-ms-shopping --region ${AWS_REGION} 2>/dev/null || true
aws ecr create-repository --repository-name shopping-ms-customer --region ${AWS_REGION} 2>/dev/null || true
aws ecr create-repository --repository-name shopping-ms-nginx-proxy --region ${AWS_REGION} 2>/dev/null || true

# Build and push products
echo "Building products image..."
docker build -t shopping-ms-products:latest -f products/Dockerfile products/
docker tag shopping-ms-products:latest ${ECR_REGISTRY}/shopping-ms-products:latest
docker push ${ECR_REGISTRY}/shopping-ms-products:latest

# Build and push shopping
echo "Building shopping image..."
docker build -t shopping-ms-shopping:latest -f shopping/Dockerfile shopping/
docker tag shopping-ms-shopping:latest ${ECR_REGISTRY}/shopping-ms-shopping:latest
docker push ${ECR_REGISTRY}/shopping-ms-shopping:latest

# Build and push customer
echo "Building customer image..."
docker build -t shopping-ms-customer:latest -f customer/Dockerfile customer/
docker tag shopping-ms-customer:latest ${ECR_REGISTRY}/shopping-ms-customer:latest
docker push ${ECR_REGISTRY}/shopping-ms-customer:latest

# Build and push nginx-proxy
echo "Building nginx-proxy image..."
docker build -t shopping-ms-nginx-proxy:latest -f proxy/Dockerfile proxy/
docker tag shopping-ms-nginx-proxy:latest ${ECR_REGISTRY}/shopping-ms-nginx-proxy:latest
docker push ${ECR_REGISTRY}/shopping-ms-nginx-proxy:latest

echo "All images pushed to ECR!"
echo "Update Dockerrun.aws.json with: ${ECR_REGISTRY}"

