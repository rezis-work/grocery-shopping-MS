# AWS Elastic Beanstalk Deployment Guide

## Prerequisites

1. AWS CLI configured with appropriate credentials
2. Docker installed locally
3. AWS ECR access permissions

## Important Notes

⚠️ **MongoDB**: Elastic Beanstalk is not ideal for running MongoDB. Consider using:
- **AWS DocumentDB** (MongoDB-compatible managed service)
- **MongoDB Atlas** (cloud-hosted MongoDB)
- **EC2 instance** with MongoDB (separate from Elastic Beanstalk)

## Deployment Steps

### 1. Set Up ECR Repositories

Update `build-and-push.sh` with your AWS account ID and region, then run:

```bash
chmod +x build-and-push.sh
./build-and-push.sh
```

Or manually create ECR repositories:
```bash
aws ecr create-repository --repository-name shopping-ms-products --region <your-region>
aws ecr create-repository --repository-name shopping-ms-shopping --region <your-region>
aws ecr create-repository --repository-name shopping-ms-customer --region <your-region>
aws ecr create-repository --repository-name shopping-ms-nginx-proxy --region <your-region>
```

### 2. Build and Push Docker Images

```bash
# Set your AWS account ID and region
export AWS_ACCOUNT_ID="123456789012"
export AWS_REGION="us-east-1"
export ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

# Login to ECR
aws ecr get-login-password --region ${AWS_REGION} | docker login --username AWS --password-stdin ${ECR_REGISTRY}

# Build and push each service
docker build -t shopping-ms-products:latest -f products/Dockerfile products/
docker tag shopping-ms-products:latest ${ECR_REGISTRY}/shopping-ms-products:latest
docker push ${ECR_REGISTRY}/shopping-ms-products:latest

docker build -t shopping-ms-shopping:latest -f shopping/Dockerfile shopping/
docker tag shopping-ms-shopping:latest ${ECR_REGISTRY}/shopping-ms-shopping:latest
docker push ${ECR_REGISTRY}/shopping-ms-shopping:latest

docker build -t shopping-ms-customer:latest -f customer/Dockerfile customer/
docker tag shopping-ms-customer:latest ${ECR_REGISTRY}/shopping-ms-customer:latest
docker push ${ECR_REGISTRY}/shopping-ms-customer:latest

docker build -t shopping-ms-nginx-proxy:latest -f proxy/Dockerfile proxy/
docker tag shopping-ms-nginx-proxy:latest ${ECR_REGISTRY}/shopping-ms-nginx-proxy:latest
docker push ${ECR_REGISTRY}/shopping-ms-nginx-proxy:latest
```

### 3. Update Dockerrun.aws.json

Replace placeholders in `Dockerrun.aws.json`:
- `<YOUR_ECR_REGISTRY>` → Your ECR registry URL (e.g., `123456789012.dkr.ecr.us-east-1.amazonaws.com`)
- `<MONGODB_HOST>` → Your MongoDB host (DocumentDB endpoint, MongoDB Atlas URI, or EC2 instance)

Example:
```json
"image": "123456789012.dkr.ecr.us-east-1.amazonaws.com/shopping-ms-products:latest"
"value": "mongodb://docdb-cluster.xxxxx.us-east-1.docdb.amazonaws.com:27017/products"
```

### 4. Create Deployment Package

```bash
# Create a zip file with Dockerrun.aws.json
zip deploy.zip Dockerrun.aws.json
```

### 5. Deploy to Elastic Beanstalk

```bash
# Using EB CLI (if installed)
eb init -p docker shopping-ms
eb create shopping-ms-env
eb deploy

# Or upload deploy.zip via AWS Console
```

## Alternative: Single Container Deployment

If you prefer to deploy one service at a time:

1. Create a `Dockerfile` in the root that builds one service
2. Deploy each service to separate Elastic Beanstalk environments
3. Use Application Load Balancer to route traffic

## Environment Variables

Make sure to set these in Elastic Beanstalk environment configuration:
- `MONGODB_URI` (if not in Dockerrun.aws.json)
- `APP_SECRET`
- `MESSAGE_BROKER_URL` (if using RabbitMQ)

## Troubleshooting

- **Image not found**: Ensure images are pushed to ECR and Dockerrun.aws.json has correct image paths
- **MongoDB connection issues**: Verify MongoDB host is accessible from Elastic Beanstalk security group
- **Port conflicts**: Ensure port mappings in Dockerrun.aws.json match your application ports

