const ShoppingService = require("../services/shopping-service");
const UserAuth = require('./middlewares/auth');
const { PublishMessage, SubscribeMessage } = require("../utils");
const { CUSTOMER_BINDING_KEY, SHOPPING_BINDING_KEY } = require("../config");

module.exports = (app, channel) => {
    
    const service = new ShoppingService();

    if (channel) {
        SubscribeMessage(channel, service, SHOPPING_BINDING_KEY);
    }

    app.post('/order',UserAuth, async (req,res,next) => {

        const { _id } = req.user;
        const { txnNumber } = req.body;


        try {
            const { data } = await service.PlaceOrder({_id, txnNumber});
            const { data: payloadData } = await service.getOrderPayload(_id, data, 'CREATE_ORDER');
            // payloadData is already { event, data: {...} } after extracting from FormateData wrapper
            // Send it directly to the customer service
            // PublishCustomerEvent(payloadData);
            PublishMessage(channel, CUSTOMER_BINDING_KEY, JSON.stringify(payloadData))
            return res.status(200).json(data);
            
        } catch (err) {
            next(err)
        }

    });

    app.get('/orders',UserAuth, async (req,res,next) => {

        const { _id } = req.user;

        try {
            const { data } = await service.GetOrders(_id);
            return res.status(200).json(data);
        } catch (err) {
            next(err);
        }

    });
       
    
    app.get('/cart', UserAuth, async (req,res,next) => {

        const { _id } = req.user;
        try {
            const { data } = await service.GetCart({_id});
            return res.status(200).json(data);
        } catch (err) {
            next(err);
        }
    });
}